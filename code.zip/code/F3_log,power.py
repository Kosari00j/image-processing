import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('image.jpg')

gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

log_transformed = np.log1p(gray_image)
inv_log_transformed = np.expm1(log_transformed)

power_transformed1 = np.power(gray_image, 1.5)
power_transformed2 = np.power(gray_image,0.5)


plt.figure(figsize=(12,6))

plt.subplot(231)
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.title('Original ')

plt.subplot(232)
plt.imshow(gray_image, cmap='gray')
plt.title('Grayscale ')

plt.subplot(233)
plt.imshow(log_transformed, cmap='gray')
plt.title('Logarithm ')

plt.subplot(234)
plt.imshow(inv_log_transformed, cmap='gray')
plt.title('Inverse Logarithm')

plt.subplot(235)
plt.imshow(power_transformed1, cmap='gray')
plt.title('Power 1.5')

plt.subplot(236)
plt.imshow(power_transformed2, cmap='gray')
plt.title('Power 0.4')


plt.show()


