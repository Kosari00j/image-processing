
import cv2
import numpy as np
import matplotlib.pyplot as plt

img= 'fourier.jpg'
image = cv2.imread(img)

gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

dft = np.fft.fft2(gray_image)
dft_shift = np.fft.fftshift(dft)

rows, cols = gray_image.shape
crow, ccol = rows // 2 , cols // 2

sigma = 20
x = np.linspace(-ccol, ccol, cols)
y = np.linspace(-crow, crow, rows)
x, y = np.meshgrid(x, y)

gaussian_filter = np.exp(-(x**2 + y**2) / (2 * sigma**2))
high_pass_filter = 1 - gaussian_filter

gaussian_dft = dft_shift * gaussian_filter
gaussian_dft_shift = np.fft.ifftshift(gaussian_dft)
gaussian_image = np.fft.ifft2(gaussian_dft_shift)
gaussian_image = np.abs(gaussian_image)


gaussian_dft_high_pass = dft_shift * high_pass_filter
gaussian_dft_high_pass_shift = np.fft.ifftshift(gaussian_dft_high_pass)
gaussian_image_high_pass = np.fft.ifft2(gaussian_dft_high_pass_shift)
gaussian_image_high_pass = np.abs(gaussian_image_high_pass)


plt.figure(figsize=(12, 6))

plt.subplot(2, 3, 1)
plt.title('Original Gray Image')
plt.imshow(gray_image, cmap='gray')

plt.subplot(2, 3, 2)
plt.title('Original In Frequency Domain')
plt.imshow(np.log1p(np.abs(dft_shift)), cmap='gray')

plt.subplot(2, 3, 3)
plt.title('Gaussian Filtered Image Low Pass')
plt.imshow(gaussian_image, cmap='gray')

plt.subplot(2, 3, 4)
plt.title('Gaussian Filter in Frequency Domain')
plt.imshow(gaussian_filter, cmap='gray')

plt.subplot(2, 3, 5)
plt.title('Gaussian Filter High Pass')
plt.imshow(high_pass_filter, cmap='gray')

plt.subplot(2, 3, 6)
plt.title('Gaussian Filtered Image High Pass')
plt.imshow(gaussian_image_high_pass, cmap='gray')

plt.show()


