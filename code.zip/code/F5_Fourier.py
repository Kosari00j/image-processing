import cv2
import numpy as np
from matplotlib import pyplot as plt

image = cv2.imread('fourier.jpg')

gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

f_transformed = np.fft.fft2(gray_image)
fshift = np.fft.fftshift(f_transformed)
magnitude_spectrum = 20 * np.log(np.abs(fshift))


plt.figure(figsize=(12,6))

plt.subplot(231)
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.title('Original ')

plt.subplot(232)
plt.imshow(gray_image, cmap='gray')
plt.title('Grayscale ')

plt.subplot(233)
plt.imshow(magnitude_spectrum, cmap='gray')
plt.title('Fourier ')

plt.show()