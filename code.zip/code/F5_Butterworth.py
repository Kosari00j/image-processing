import cv2
import numpy as np
import matplotlib.pyplot as plt

img= 'fourier.jpg'
image = cv2.imread(img)

gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

dft = np.fft.fft2(gray_image)
dft_shift = np.fft.fftshift(dft)

rows, cols = gray_image.shape
crow, ccol = rows // 2 , cols // 2
D0 = 30 
n = 2   

x = np.linspace(-ccol, ccol, cols)
y = np.linspace(-crow, crow, rows)
x, y = np.meshgrid(x, y)
D = np.sqrt(x**2 + y**2)

butterworth_filter = 1 / (1 + (D / D0)**(2 * n))
high_pass_filter = 1 - butterworth_filter


butterworth_dft = dft_shift * butterworth_filter
butterworth_dft_shift = np.fft.ifftshift(butterworth_dft)
butterworth_image = np.fft.ifft2(butterworth_dft_shift)
butterworth_image = np.abs(butterworth_image)


butterworth_dft_high_pass = dft_shift * high_pass_filter
butterworth_dft_high_pass_shift = np.fft.ifftshift(butterworth_dft_high_pass)
butterworth_image_high_pass = np.fft.ifft2(butterworth_dft_high_pass_shift)
butterworth_image_high_pass = np.abs(butterworth_image_high_pass)


plt.figure(figsize=(12, 6))

plt.subplot(2, 3, 1)
plt.title('Original Gray Image')
plt.imshow(gray_image, cmap='gray')

plt.subplot(2, 3, 2)
plt.title('Original In Frequency Domain')
plt.imshow(np.log1p(np.abs(dft_shift)), cmap='gray')

plt.subplot(2, 3, 3)
plt.title('Butterworth Filtered Image')
plt.imshow(butterworth_image, cmap='gray')

plt.subplot(2, 3, 4)
plt.title('Butterworth Filter Low Pass')
plt.imshow(np.log(np.abs(butterworth_filter) + 1), cmap='gray')

plt.subplot(2, 3, 5)
plt.title('Butterworth Filter High Pass')
plt.imshow(np.log(np.abs(high_pass_filter) + 1), cmap='gray')

plt.subplot(2, 3, 6)
plt.title('Butterworth Filtered Image High Pass')
plt.imshow(butterworth_image_high_pass, cmap='gray')

plt.show()
