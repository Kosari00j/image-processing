import cv2
import matplotlib.pyplot as plt

img = cv2.imread('negative.jpg')

gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

negative_img = cv2.bitwise_not(gray_img)

plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.title('Original Image')

plt.subplot(1, 2, 2)
plt.imshow(negative_img, cmap='gray')
plt.title('Negative Image')

plt.show()

