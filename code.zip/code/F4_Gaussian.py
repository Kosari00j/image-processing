import cv2
import numpy as np
import matplotlib.pyplot as plt

img=cv2.imread('image.jpg')

gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

Gblr9=cv2.GaussianBlur(gray_image,(3,3),0)
Gblr49=cv2.GaussianBlur(gray_image,(7,7),0)
Gblr121=cv2.GaussianBlur(gray_image,(11,11),0)

# Gblur=np.vstack([np.hstack([gray_image,Gblr9]),np.hstack([Gblr49,Gblr121])])

plt.figure(figsize=(12,6))

plt.subplot(221)
plt.imshow(gray_image,cmap='gray')
plt.title('gray_image')


plt.subplot(222)
plt.imshow(Gblr9,cmap='gray')
plt.title('Gblr9')

plt.subplot(223)
plt.imshow(Gblr49,cmap='gray')
plt.title('Gblr49')


plt.subplot(224)
plt.imshow(Gblr121,cmap='gray')
plt.title('Gblr121')


# plt.subplot(222)
# plt.imshow(Gblur,cmap='gray')
# plt.title('gaussian')


plt.show()
