import cv2
import numpy as np
import matplotlib.pyplot as plt


img=cv2.imread('median.jpg')

gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

Mblr9=cv2.medianBlur(gray_image,3)
Mblr49=cv2.medianBlur(gray_image,7)
Mblr121=cv2.medianBlur(gray_image,11)

# Mblur=np.vstack([np.hstack([gray_image,Mblr9]),np.hstack([Mblr49,Mblr121])])

plt.figure(figsize=(12,6))

plt.subplot(221)
plt.imshow(gray_image,cmap='gray')
plt.title('gray_image')

plt.subplot(222)
plt.imshow(Mblr9,cmap='gray')
plt.title('Mblr9')

plt.subplot(223)
plt.imshow(Mblr49,cmap='gray')
plt.title('Mblr49')

plt.subplot(224)
plt.imshow(Mblr121,cmap='gray')
plt.title('Mblr121')

# plt.subplot(222)
# plt.imshow(Mblur,cmap='gray')
# plt.title('median')

plt.show()