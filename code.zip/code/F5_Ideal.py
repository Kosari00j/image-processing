
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = 'fourier.jpg'
image = cv2.imread(img)

gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

dft = np.fft.fft2(gray_image)
dft_shift = np.fft.fftshift(dft)

rows, cols = gray_image.shape
crow, ccol = rows // 2 , cols // 2
low_pass_filter = np.zeros((rows, cols), np.uint8)
cv2.circle(low_pass_filter, (ccol, crow), 30, 1, thickness=-1)


low_pass_dft = dft_shift * low_pass_filter
low_pass_dft_shift = np.fft.ifftshift(low_pass_dft)

low_pass_image = np.fft.ifft2(low_pass_dft_shift)
low_pass_image = np.abs(low_pass_image)

high_pass_filter = np.ones((rows, cols), np.uint8)
cv2.circle(high_pass_filter, (ccol, crow), 30, 0, thickness=-1)


high_pass_dft = dft_shift * high_pass_filter
high_pass_dft_shift = np.fft.ifftshift(high_pass_dft)
high_pass_image = np.fft.ifft2(high_pass_dft_shift)
high_pass_image = np.abs(high_pass_image)


plt.figure(figsize=(12, 6))

plt.subplot(2, 3, 1)
plt.title('Original Gray Image')
plt.imshow(gray_image, cmap='gray')


plt.subplot(2, 3, 2)
plt.title('Original In Frequency Domain')
plt.imshow(np.log1p(np.abs(dft_shift)), cmap='gray')

plt.subplot(2, 3, 3)
plt.title('Low Pass Filtered Image')
plt.imshow(low_pass_image, cmap='gray')

plt.subplot(2, 3, 4)
plt.title('High Pass Filtered Image')
plt.imshow(high_pass_image, cmap='gray')

plt.subplot(2, 3, 5)
plt.title('Low Pass Filter in Frequency Domain')
plt.imshow(np.log(np.abs(low_pass_filter) + 1), cmap='gray')

plt.subplot(2, 3, 6)
plt.title('High Pass Filter in Frequency Domain')
plt.imshow(np.log(np.abs(high_pass_filter) + 1), cmap='gray')

plt.show()