import cv2
import numpy as np
import matplotlib.pyplot as plt

img=cv2.imread('image.jpg')

gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

blr9=cv2.blur(gray_image,(3,3))
blr49=cv2.blur(gray_image,(7,7))
blr121=cv2.blur(gray_image,(11,11))

# blurred=np.vstack([np.hstack([gray_image,blr9]),np.hstack([blr49,blr121])])

plt.figure(figsize=(12,6))

plt.subplot(221)
plt.imshow(gray_image,cmap='gray')
plt.title('gray_image')

plt.subplot(222)
plt.imshow(blr9,cmap='gray')
plt.title('blr9')

plt.subplot(223)
plt.imshow(blr49,cmap='gray')
plt.title('blr49')


plt.subplot(224)
plt.imshow(blr121,cmap='gray')
plt.title('blr121')

# plt.subplot(222)
# plt.imshow(blurred,cmap='gray')
# plt.title('averaging')

plt.show()




# مقایسه کل فیلترها

# import cv2
# import numpy as np
# import matplotlib.pyplot as plt

# image = cv2.imread("image.jpg")
# gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


# filters = {
#     'Gaussian Blur 3x3': np.array([[1, 2, 1], [2, 4, 2], [1, 2, 1]]) / 16,
#     'Gaussian Blur 5x5': np.array([[1, 4, 6, 4, 1], [4, 16, 24, 16, 4], [6, 24, 36, 24, 6], [4, 16, 24, 16, 4], [1, 4, 6, 4, 1]]) / 256,
#     'Gaussian Blur 11x11': cv2.getGaussianKernel(11, 0),
#     'Average 3x3': np.ones((3, 3), np.float32) / 9,
#     'Average 5x5': np.ones((5, 5), np.float32) / 25,
#     'Average 11x11': np.ones((11, 11), np.float32) / 121,
#     'Median 3x3': None,
#     'Median 5x5': None,
#     'Median 11x11': None
# }


# plt.figure(figsize=(15, 10))

# for i, (filter_name, filter_values) in enumerate(filters.items()):
#     if 'Median' in filter_name:
#         filtered_image = cv2.filter2D(gray_image, -1, filters["Gaussian Blur 3x3"])
#         filtered_image = cv2.medianBlur(filtered_image, i * 2 + 3)
#     else:
#         filtered_image = cv2.filter2D(gray_image, -1, filter_values)

#     plt.subplot(3, 3, i + 1)
#     plt.imshow(filtered_image, cmap='gray')
#     plt.title(filter_name)
#     plt.xticks([])
#     plt.yticks([])

# plt.show()

