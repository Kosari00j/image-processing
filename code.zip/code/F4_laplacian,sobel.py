import cv2
import numpy as np
from matplotlib import pyplot as plt

img=cv2.imread('LASO.jpg')

gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

sobelx=cv2.Sobel(gray_image,cv2.CV_8U,1,0,ksize=3)
sobely=cv2.Sobel(gray_image,cv2.CV_8U,0,1,ksize=3)

laplacian=cv2.Laplacian(gray_image,cv2.CV_8U,ksize=3)

plt.subplot(2,2,1)
plt.imshow(img,'gray')
plt.title('original')


plt.subplot(2,2,2)
plt.imshow(sobelx,'gray')
plt.title('sobelx')

plt.subplot(2,2,3)
plt.imshow(sobely,'gray')
plt.title('sobely')


plt.subplot(2,2,4)
plt.imshow(laplacian,'gray')
plt.title('laplacian')

plt.show()

