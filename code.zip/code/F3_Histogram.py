import cv2 
import numpy as np 
import matplotlib.pyplot as plt 
 
image = cv2.imread('gol.jpg') 
 
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) 
hist = cv2.calcHist([gray_image], [0], None, [256], [0, 256]) 
equ = cv2.equalizeHist(gray_image) 
hist_equ = cv2.calcHist([equ], [0], None, [256], [0, 256]) 
 
 
plt.figure(figsize=(12, 6)) 
 
plt.subplot(221) 
plt.imshow(gray_image, cmap='gray') 
plt.title('Original Image') 
 
plt.subplot(222) 
plt.hist(gray_image.ravel(), 256, [0,255]) 
plt.title('Histogram') 
 
plt.subplot(223) 
plt.imshow(equ, cmap='gray') 
plt.title('Equalized Image') 
 
plt.subplot(224) 
plt.hist(equ.ravel(), 256, [0, 255]) 
plt.title('Equalized Histogram') 
 

plt.show()